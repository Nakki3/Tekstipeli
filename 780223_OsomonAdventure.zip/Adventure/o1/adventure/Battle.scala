package o1.adventure

trait Battle {
  def playerAttack:String
  def run: String
  def potion:String
  def superPotion:String
  def catchaa:String
  def opponentTurn:String
  def changeOsomon: String
  def forceChange: String
  def help:String
  def statusCheck:String
}