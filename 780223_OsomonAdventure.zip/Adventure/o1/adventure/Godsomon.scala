package o1.adventure

class Godsomon(wildLevel:Int) extends Osomon(500,500,500,500, wildLevel,"Godsomon") {
  
}