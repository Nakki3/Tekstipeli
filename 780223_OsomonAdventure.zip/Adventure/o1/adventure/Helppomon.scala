package o1.adventure

class Helppomon(level:Int) extends Osomon(150,70,100,70,level,"Helppomon") {
  
}