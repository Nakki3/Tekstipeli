package o1.adventure

class Lightningmon(level:Int) extends Osomon(20,100,10,600,level,"Lightningmon") {
  
}