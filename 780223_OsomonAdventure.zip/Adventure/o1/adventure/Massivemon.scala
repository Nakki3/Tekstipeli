package o1.adventure

class Massivemon(level:Int) extends Osomon(900,20,60,5,level,"Massivemon") {
  
}