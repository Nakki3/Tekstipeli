package o1.adventure

class Paskamon(levu:Int)extends Osomon(50,50,50,50,levu,"Paskamon") {
  
}