package o1.adventure

class Rippermon(level:Int) extends Osomon(60,350,80,120,level,"Rippermon") {
  
}