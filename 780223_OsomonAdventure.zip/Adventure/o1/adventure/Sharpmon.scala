package o1.adventure

class Sharpmon(level:Int) extends Osomon(120,200,90,60,level,"Sharpmon") {
  
}