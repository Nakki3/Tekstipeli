package o1.adventure

class Sikamon(wildLevel: Int) extends Osomon(400,40,30,12,wildLevel,"Sikamon") {
  
 
}