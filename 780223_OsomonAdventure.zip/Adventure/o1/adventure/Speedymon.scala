package o1.adventure

class Speedymon(level:Int)extends Osomon(40,90,30,200,level,"Speedymon") {
  
}