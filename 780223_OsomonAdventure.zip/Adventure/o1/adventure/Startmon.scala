package o1.adventure

class Startmon(level:Int) extends Osomon(100,100,100,100,level,"Startmon") {
  
}