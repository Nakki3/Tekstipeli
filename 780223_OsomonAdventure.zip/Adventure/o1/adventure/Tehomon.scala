package o1.adventure

class Tehomon(level:Int) extends Osomon(150,120,130,160,level,"Tehomon") {
  
}