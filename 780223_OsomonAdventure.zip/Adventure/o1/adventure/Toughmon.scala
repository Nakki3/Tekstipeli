package o1.adventure

class Toughmon(level:Int) extends Osomon(300,100,500,10,level,"Toughmon") {
  
}